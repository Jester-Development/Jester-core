fx_version 'cerulean'
game 'gta5'

author 'Jester Dev'
description 'Jester-core - A universal core for QBCore, ESX, and vRP integration.'
version '1.0.0'

shared_scripts {
    'config.lua'
}

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}
