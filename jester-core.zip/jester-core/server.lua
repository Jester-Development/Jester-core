local JesterCore = {}

-- Framework Configuration
local initialized = false

Citizen.CreateThread(function()
    while not initialized do
        -- QBCore Initialization
        if Config.EnableQBCore and GetResourceState('qb-core') == 'started' and not JesterCore.QBCore then
            local qbCoreExport = exports['qb-core']

            if qbCoreExport and qbCoreExport.GetCoreObject then

                JesterCore.QBCore = qbCoreExport:GetCoreObject()

                print("[Jester-core] QBCore initialized.")

            end

        end


        -- ESX Initialization

        if Config.EnableESX and GetResourceState('es_extended') == 'started' and not JesterCore.ESX then

            JesterCore.ESX = exports['es_extended']:getSharedObject()

            print("[Jester-core] ESX initialized.")

        end


        -- vRP Initialization

        if Config.EnableVRP and GetResourceState('vrp') == 'started' and not JesterCore.vRP then

            if Proxy then

                JesterCore.vRP = Proxy.getInterface("vRP")

                JesterCore.vRPClient = Tunnel.getInterface("vRP", "jester-core")

                print("[Jester-core] vRP initialized.")

            else

                print("[Jester-core] Proxy is nil, cannot initialize vRP.")

            end

        end


        -- Check if any framework was initialized

        if JesterCore.QBCore or JesterCore.ESX or JesterCore.vRP then

            initialized = true

            print("[Jester-core] Framework successfully initialized.")

        else

            print("[Jester-core] Framework not ready. Retrying...")

            Citizen.Wait(2000) -- Wait before retrying

        end

    end

end)
-- Unified API: Get Player Data
function JesterCore.GetPlayer(source)
    if JesterCore.QBCore then
        return JesterCore.QBCore.Functions.GetPlayer(source)
    elseif JesterCore.ESX then
        return JesterCore.ESX.GetPlayerFromId(source)
    elseif JesterCore.vRP then
        local user_id = JesterCore.vRP.getUserId({source})
        return {id = user_id, source = source}
    end
    return nil
end

-- Unified Money Getter
function JesterCore.GetPlayerMoney(source)
    local money = 0
    if JesterCore.QBCore then
        local player = JesterCore.QBCore.Functions.GetPlayer(source)
        if player then
            money = player.PlayerData.money['cash']
        end
    elseif JesterCore.ESX then
        local player = JesterCore.ESX.GetPlayerFromId(source)
        if player then
            money = player.getMoney()
        end
    elseif JesterCore.vRP then
        local user_id = JesterCore.vRP.getUserId({source})
        if user_id then
            money = JesterCore.vRP.getMoney({user_id})
        end
    end
    return money
end

-- Unified Money Setter
function JesterCore.SetPlayerMoney(source, amount)
    if JesterCore.QBCore then
        local player = JesterCore.QBCore.Functions.GetPlayer(source)
        if player then
            player.Functions.SetMoney('cash', amount)
        end
    elseif JesterCore.ESX then
        local player = JesterCore.ESX.GetPlayerFromId(source)
        if player then
            player.setMoney(amount)
        end
    elseif JesterCore.vRP then
        local user_id = JesterCore.vRP.getUserId({source})
        if user_id then
            JesterCore.vRP.setMoney({user_id, amount})
        end
    end
end

-- Example Command: Check Money
RegisterCommand('checkmoney', function(source, args, rawCommand)
    local money = JesterCore.GetPlayerMoney(source)
    TriggerClientEvent('chat:addMessage', source, {
        args = {"Money", "You have $" .. money}
    })
end, false)

-- Example Command: Set Money
RegisterCommand('setmoney', function(source, args, rawCommand)
    local amount = tonumber(args[1])
    if amount then
        JesterCore.SetPlayerMoney(source, amount)
        TriggerClientEvent('chat:addMessage', source, {
            args = {"Money", "Your money has been set to $" .. amount}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            args = {"Error", "Invalid amount!"}
        })
    end
end, false)

-- Exporting Functions
exports('GetPlayer', JesterCore.GetPlayer)
exports('GetPlayerMoney', JesterCore.GetPlayerMoney)
exports('SetPlayerMoney', JesterCore.SetPlayerMoney)
