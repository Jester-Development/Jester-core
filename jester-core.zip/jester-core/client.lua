local JesterCore = {}

-- Framework Initialization (Client-Side)
Citizen.CreateThread(function()
    local initialized = false

    while not initialized do
        if Config.EnableQBCore and GetResourceState('qb-core') == 'started' then
            local qbCoreExport = exports['qb-core']
            
            -- Check for available QBCore exports
            if qbCoreExport and qbCoreExport.GetCoreObject then
                JesterCore.QBCore = qbCoreExport:GetCoreObject()
                print("[Jester-core] QBCore initialized using GetCoreObject.")
            elseif qbCoreExport and qbCoreExport.GetSharedObject then
                JesterCore.QBCore = qbCoreExport:GetSharedObject()
                print("[Jester-core] QBCore initialized using GetSharedObject.")
            elseif QBCore then
                JesterCore.QBCore = QBCore
                print("[Jester-core] QBCore initialized using direct global reference.")
            end
        end

        if Config.EnableESX and GetResourceState('es_extended') == 'started' then
            JesterCore.ESX = exports['es_extended']:getSharedObject()
            print("[Jester-core] ESX initialized.")
        end

        if Config.EnableVRP and GetResourceState('vrp') == 'started' then
            JesterCore.vRP = Proxy.getInterface("vRP")
            JesterCore.vRPClient = Tunnel.getInterface("vRP", "jester-core")
            print("[Jester-core] vRP initialized.")
        end

        -- Check if any framework was initialized
        if JesterCore.QBCore or JesterCore.ESX or JesterCore.vRP then
            initialized = true
            print("[Jester-core] Framework successfully initialized.")
        else
            -- Wait and retry initialization
            Citizen.Wait(1000)
        end
    end
end)

-- Example Command: Show Money
RegisterCommand('jester_money', function()
    local source = PlayerId()
    local money = 0

    if JesterCore.QBCore then
        local player = JesterCore.QBCore.Functions.GetPlayer(source)
        if player then
            money = player.PlayerData.money['cash']
        end
    elseif JesterCore.ESX then
        local player = JesterCore.ESX.GetPlayerFromId(source)
        if player then
            money = player.getMoney()
        end
    elseif JesterCore.vRP then
        local user_id = JesterCore.vRP.getUserId({source})
        if user_id then
            money = JesterCore.vRP.getMoney({user_id})
        end
    end

    if money > 0 then
        print("[Jester-core] Your Money: $" .. money)
    else
        print("[Jester-core] No money data available.")
    end
end, false)
