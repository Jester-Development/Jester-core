Config = {}

-- Enable or disable support for frameworks
Config.EnableQBCore = true
Config.EnableESX = true
Config.EnableVRP = true
